export class CreateDealDto {}
