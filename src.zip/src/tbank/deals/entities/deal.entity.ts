export class Deal {}
