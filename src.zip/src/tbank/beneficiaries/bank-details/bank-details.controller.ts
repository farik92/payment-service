import { Controller } from '@nestjs/common';

@Controller('bank-details')
export class BankDetailsController {}
